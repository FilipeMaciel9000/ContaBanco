package models;

public abstract class Conta {
    private int numero;
    private String agencia;
    private String titular;
    protected double saldo;

    public Conta(int numero, String agencia, String titular, double saldoInicial) {
        this.numero = numero;
        this.agencia = agencia;
        this.titular = titular;
        this.saldo = Math.max(saldoInicial, 0);
    }

    public void depositar(double valor) {
        if (valor <= 0) {
            System.out.println("Erro: Valor inválido para depósito.");
            return;
        }
        saldo += valor;
        System.out.printf("Depósito de R$%.2f realizado.%n", valor);
    }

    public void sacar(double valor) {
        if (valor <= 0 || valor > saldo) {
            System.out.println("Erro: Saque inválido.");
        } else {
            saldo -= valor;
            System.out.printf("Saque de R$%.2f realizado.%n", valor);
        }
    }

    public void transferir(Conta destino, double valor) {
        if (valor <= 0 || valor > saldo) {
            System.out.println("Erro: Transferência inválida.");
            return;
        }
        this.saldo -= valor;
        destino.depositar(valor);
        System.out.printf("Transferência de R$%.2f para %s realizada.%n", valor, destino.getTitular());
    }

    public void extrato() {
        System.out.println("=== Extrato ===");
        System.out.printf("Titular: %s%nAgência: %s%nConta: %d%nSaldo: R$%.2f%n",
                titular, agencia, numero, saldo);
    }

    public String getTitular() {
        return titular;
    }

    public double getSaldo() {
        return saldo;
    }
}

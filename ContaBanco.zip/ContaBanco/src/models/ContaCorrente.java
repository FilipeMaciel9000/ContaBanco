package models;

public class ContaCorrente extends Conta {
    private final double taxaOperacao = 1.0;

    public ContaCorrente(int numero, String agencia, String titular, double saldoInicial) {
        super(numero, agencia, titular, saldoInicial);
    }

    @Override
    public void sacar(double valor) {
        double total = valor + taxaOperacao;
        System.out.printf("Saque com taxa de R$%.2f.%n", taxaOperacao);
        super.sacar(total);
    }
}

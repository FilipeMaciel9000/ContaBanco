package models;

public class ContaPoupanca extends Conta {
    public ContaPoupanca(int numero, String agencia, String titular, double saldoInicial) {
        super(numero, agencia, titular, saldoInicial);
    }

    // Usa o comportamento padrão de saque
}

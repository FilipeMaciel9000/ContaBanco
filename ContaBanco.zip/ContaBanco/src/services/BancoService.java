package services;

import models.Conta;

public class BancoService {

    public void realizarOperacoes(Conta origem, Conta destino) {
        origem.depositar(500);
        origem.sacar(100);
        origem.transferir(destino, 200);

        System.out.println();
        origem.extrato();
        System.out.println();
        destino.extrato();
    }
}

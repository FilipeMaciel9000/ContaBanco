package utils;

import java.util.Scanner;
import models.ContaCorrente;
import models.ContaPoupanca;

public class ContaFactory {
    public static ContaCorrente criarContaCorrente(Scanner scanner) {
        System.out.println("Criando Conta Corrente:");
        return new ContaCorrente(
                lerInt(scanner, "Número da conta: "),
                lerString(scanner, "Agência: "),
                lerString(scanner, "Titular: "),
                lerDouble(scanner, "Saldo inicial: ")
        );
    }

    public static ContaPoupanca criarContaPoupanca(Scanner scanner) {
        System.out.println("Criando Conta Poupança:");
        return new ContaPoupanca(
                lerInt(scanner, "Número da conta: "),
                lerString(scanner, "Agência: "),
                lerString(scanner, "Titular: "),
                lerDouble(scanner, "Saldo inicial: ")
        );
    }

    private static int lerInt(Scanner scanner, String msg) {
        System.out.print(msg);
        return scanner.nextInt();
    }

    private static double lerDouble(Scanner scanner, String msg) {
        System.out.print(msg);
        return scanner.nextDouble();
    }

    private static String lerString(Scanner scanner, String msg) {
        System.out.print(msg);
        scanner.nextLine(); // consumir quebra de linha
        return scanner.nextLine();
    }
}

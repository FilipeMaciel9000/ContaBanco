import models.ContaCorrente;
import models.ContaPoupanca;
import services.BancoService;
import utils.ContaFactory;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        ContaCorrente cc = ContaFactory.criarContaCorrente(scanner);
        ContaPoupanca cp = ContaFactory.criarContaPoupanca(scanner);

        BancoService banco = new BancoService();
        banco.realizarOperacoes(cc, cp);

        scanner.close();
    }
}
